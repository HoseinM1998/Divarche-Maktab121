$(".clockpicker").clockpicker({
    "donetext": "قبول"
});

$(".clockpicker-autoclose").clockpicker({
    "donetext": "قبول",
    autoclose: true
});

$(".clockpicker-now").clockpicker({
    "donetext": "قبول",
    'default': 'now'
});